package com.demo.kafka;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

//import com.demo.kafka.Message;

public class AvroConsumer {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Properties props = new Properties();
		props.setProperty("bootstrap.servers", "localhost:9092");
		props.put("group.id", "g07");
		props.setProperty("auto.offset.reset", "earliest");
		props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer");
		props.put("schema.registry.url", "http://localhost:8081");

		try (KafkaConsumer consumer = new KafkaConsumer<>(props)) {
			consumer.subscribe(Arrays.asList("test"));

			while (true) {
				ConsumerRecords records = consumer.poll(100);
//				records.forEach(record -> System.out.println(record.value()));

				for (Object record : records) {
					ConsumerRecord crecord = (ConsumerRecord) record;
					System.out.println(crecord.value());
				}
			}
		}
	}
}